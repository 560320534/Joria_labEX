import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumedata = {
    imagescr:'https://scontent.fmnl4-1.fna.fbcdn.net/v/t39.30808-6/332770876_1040296423477409_4808561646628382642_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=9c7eae&_nc_eui2=AeHyh8_kpMI-AlPMq6PxNvH0Qug3EofadPZC6DcSh9p09rfVtplJYE9RbXPoONjOBrG2tWmnyHlCJrQzyw4JrzrE&_nc_ohc=R4mjiI8gg-8AX9WmDiY&_nc_ht=scontent.fmnl4-1.fna&oh=00_AfDmCpnQgiTfuPSX9Fw0lO_MsWfE0Kk1pfbO8SceUh0yXQ&oe=65DC0891',
    name: 'Jay Jay Joria',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Malinta Elementary School',
      elementaryyear: '2014',
      highschool: 'Malinta National High School',
      highschoolyear: '2019',
      seniorhighschool: 'Datamex College of St. Adeline',
      seniorhighschoolyear: '2021',
      college: 'Global Reciprocal College',
      collegeyear: '2021-present'
    },
    about: 'I am currently studying Bachelor of Science in Information Technology at Global Reciprocal College. I took BSIT because I want to explore more things that are related to computers and I want to become a Web Developer someday.',
    project: {
      projectname: 'IT support',
      imagescr: 'https://i.imgur.com/ZaCnV74.jpg',
      description: 'As a scholar of Malalaf, I am in gratis duty in the IT department and I am not a part of the PCs in different departments.'
    },
    contact: {
      mobile: '09957556603',
      email: 'dacubajayjay@gmail.com'
    }
  };

  const handlePress = () => {
    setCurrentSection(prevSection => {
      switch (prevSection) {
        case 'name':
          return 'education';
        case 'education':
          return 'about';
        case 'about':
          return 'project';
        case 'project':
          return 'contact';
        case 'contact':
          return 'name';
        default:
          return 'name';
      }
    });
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.container}>
          {currentSection === 'name' && (
            <>
              <Image source={resumedata.imageUrl} style={styles.image} />
              <View style={styles.container}>
                <Text style={styles.header}>{resumedata.name}</Text>
                <Text style={styles.info}>{resumedata.course}</Text>
              </View>
            </>
          )}
        </TouchableOpacity>

        {currentSection === 'education' && (
          <View style={styles.textcontainer}>
            <Text style={styles.header1}>Education:</Text>
            <Text style={styles.projecttitle}>{'\n'}College:</Text>
            <Text style={styles.info}>{resumedata.education.college}</Text>
            <Text> | </Text>
            <Text>{resumedata.education.collegeyear}</Text>

            <Text style={styles.projecttitle}>{'\n'}High School:</Text>
            <Text style={styles.info}>{resumedata.education.highschool}</Text>
            <Text> | </Text>
            <Text>{resumedata.education.highschoolyear}</Text>

            <Text style={styles.projecttitle}>{'\n'}Elementary:</Text>
            <Text style={styles.info}>{resumedata.education.elementary}</Text>
            <Text> | </Text>
            <Text>{resumedata.education.elementaryyear}</Text>
          </View>
        )}

        {currentSection === 'about' && (
          <View style={styles.textcontainer}>
            <Text style={styles.header1}>About Me:</Text>
            <Text>{resumedata.about}</Text>
          </View>
        )}
        
{currentSection === 'project' && (
  <View style={styles.textcontainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projecttitle}>{resumedata.project.projectname}</Text>
    <Image source={{uri: resumedata.project.imagescr}} style={styles.image} />
    <Text>{resumedata.project.description}</Text>
  </View>
)}

{currentSection === 'contact' && (
  <View style={styles.textcontainer}>
    <Text style={styles.header1}>Contact Information:</Text>
    <Text style={styles.info}>Mobile: {resumedata.contact.mobile}</Text>
    <Text style={styles.info}>Email: {resumedata.contact.email}</Text>
  </View>
)}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 10,
  },
  info: {
    fontSize: 18,
    marginTop: 5,
  },
  textcontainer: {
    margin: 20,
  },
  header1: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  projecttitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
  },
});

export default App;